truck_capacity = 24e3
gaz_capacity = 1350

# Вес груза не обязательно целое число, поэтому float
# weight = float(input("Введите вес груза: "))
# weight = 54940
weight = 56940-600
# Попоробуйте вес = 54940
# Т.к. weight - float число, кол-во машин надо
# ЯВНО привести к типу int
truck_number = int(weight // truck_capacity)
remain = weight % truck_capacity
gazel_number = int(remain // gaz_capacity)
remain_final = remain % gaz_capacity



# Использование блока if "в лоб".
# Обратите внимание, что условия взаимоисключающиеся. Только один if будет в реальности работать, но проверять будет все
# if remain_final <= 1.0:
#     print("Все поместилось")
# if 1.0 < remain_final < 25.0:
#     print("Остаток ждет самовывоза: ", remain_final )
# if 25.0 < remain_final < 300:
#     print("Остаток отправлен на машине директора: ", remain_final )
# if remain_final >= 300:
#     gazel_number = gazel_number + 1

# Здесь используем переменные bool типа.
# Обратите внимание на то, что имя переменной должно подсказывать какого типа у нее данные.
check_all_in_place = 1.0 < remain_final < 25.0
check_pickup = 1.0 < remain_final < 25.0
check_director_car = 25.0 < remain_final < 300
check_need_gazel = remain_final >= 300

# Использование блока if + else, т.к. условия условия взаимоисключающиеся.
# Код стал "ступенчатым" поэтому трудночитаемым
# if check_all_in_place:
#     print("Все поместилось")
# else:
#         if check_pickup:
#             print("Остаток ждет самовывоза: ", remain_final )
#         else:
#             if check_director_car:
#                 print("Остаток отправлен на машине директора: ", remain_final )
#             else:
#                 if check_need_gazel:
#                     gazel_number = gazel_number + 1

# Использование блока if + elif, т.к. условия условия взаимоисключающиеся.
# "Ступенчатость" кода устранена

if check_all_in_place:
    print("Все поместилось")
elif check_pickup:
    print("Остаток ждет самовывоза: ", remain_final )
elif check_director_car:
    print("Остаток отправлен на машине директора: ", remain_final )
elif check_need_gazel:
    gazel_number = gazel_number + 1
