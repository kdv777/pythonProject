# В транспортной фирме в наличии есть машины
#   truck(фура) грузоподъемность 24 тонны,
#   газель ГАЗ 2705 – 1.35 тонны;
# Перевозить фурами выгоднее.
# Вычислить оптимальное кол-во машин обоих типов для перевозки груза заданного веса.


truck_capacity = 24e3
gaz_capacity = 1350


# Вес груза не обязательно целое число, поэтому float
# weight = float(input("Введите вес груза: "))
# weight = 54940
weight = 56940-600
# Попоробуйте вес = 54940
# Т.к. weight - float число, кол-во машин надо
# ЯВНО привести к типу int
truck_number = int(weight // truck_capacity)
remain = weight % truck_capacity
gazel_number = int(remain // gaz_capacity)
remain_final = remain % gaz_capacity