truck_capacity = 24e3
gaz_capacity = 1350


# Вес груза не обязательно целое число, поэтому float
# weight = float(input("Введите вес груза: "))
# weight = 54940
weight = 56940-600
# Попоробуйте вес = 54940
# Т.к. weight - float число, кол-во машин надо
# ЯВНО привести к типу int
truck_number = int(weight // truck_capacity)
remain = weight % truck_capacity
gazel_number = int(remain // gaz_capacity)
remain_final = remain % gaz_capacity

# Использование блока if + elif, т.к. условия условия взаимоисключающиеся.
# "Ступенчатость" кода устранена
if remain_final <= 0.0:
    print("Все поместилось")
elif 1.0 < remain_final < 25.0:
    print("Остаток ждет самовывоза: ", remain_final )
elif 25.0 < remain_final < 300:
    print("Остаток отправлен на машине директора: ", remain_final )
elif remain_final >= 300:
    gazel_number = gazel_number + 1


truck_counter = 1
while truck_counter <= truck_number:
    print("Фура ", truck_counter, "отправлена")
    truck_counter = truck_counter + 1

gazel_counter = 1
while gazel_counter <= gazel_number:
    print("Газель ", gazel_counter, "отправлена")
    gazel_counter = gazel_counter + 1

#  Если кол-во машин в фирме ограничено, то груз придется разбивать на этапы
truck_counter = 1
while truck_counter <= truck_number:
    print("Фура ", truck_counter, "отправлена")
    truck_counter = truck_counter + 1

gazel_limit = 3
gazel_counter = 1
while gazel_counter <= gazel_number:
    if  gazel_counter > gazel_limit:
        print("Кол-во газелей превышено. Нужен еще этап")
        break
        # Здесь важно понимать, что использование break НЕ НЕОБХОДИМО.
        # Можно изменить само условие цикла так, что gazel_counter > gazel_limit будет в него входить
        # Но часто использование break более НАГЛЯДНО
    print("Газель ", gazel_counter, "отправлена")
    gazel_counter = gazel_counter + 1
