# Определение "в лоб" простых чисел
# ПСЕВДОКОД:
# Для заданного числа проверяем все числа меньшие его.
# Если хотя бы для одного остаток от деления равен нулю,  т.е. делется нацело - число не явлется простым

max_number = 122
current_number = 1
while current_number <= max_number:
    backward_number = current_number-1
    prime_flag = True
    # Цикл "назад" по числам.
    while backward_number >= 2:
        if current_number % backward_number == 0:
            prime_flag = False
            # Одного деления без остатка - достаточно. Дальше можно не проверять
            # прерываем цикл
            break
        backward_number -= 1
    if prime_flag:
        print(current_number)
    current_number += 1