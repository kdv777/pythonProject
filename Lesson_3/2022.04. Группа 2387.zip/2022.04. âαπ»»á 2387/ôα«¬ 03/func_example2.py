# Принцип SRP для функций:
# Каждая функция выполняет какой то один функционал:
# Разделяем этап вычислений и и этап вывода на печать
def fraction(number, divisor=4):
    solid = number // divisor
    remainder = number % divisor
    # Обратите внимание: чтобы выделить печать в отдельную функцию
    # придется передавать все параметры, а не только то, что вычислено
    return number, solid, divisor, remainder
        # print(f"{number} = {solid}*{divisor} + {remainder}")


def print_fraction(number, solid, divisor, remainder):
    # Здесь не лучшая архитектура: я знаю, что fraction возвращает кортеж из 4х чисел
    # Но эта функция принимает 4 числа, а не кортеж.
    # Т.е. результат действия одной функции не совпадает с тем, что ржидает другая в качестве аргументов
    print(f"{number} = {solid}*{divisor} + {remainder}")


num1 = 14
num2 = 19
div1 = 3

# Используйте debugger, чтобы лучше понять как происходит переход в
# функцию и обратно
frac1 = fraction(num1, div1) # Здесь frac1 - это кортеж
# Так: В лоб, но некрасиво
print_fraction(frac1[0],frac1[1],frac1[2],frac1[3])
# Или так - распаковка. Но не увлекайтесь!
print_fraction(*frac1)
# Запись в одну строку (но распаковка потребуется)
print_fraction(*fraction(num2, divisor=div1))
# Важно понимать, что распаковки можно было бы избежать
#  если бы функция print_fraction имела бы один параметр - кортеж чисел:
# def print_fraction(tiple_of_number):

