# Простейшая функция - вычисление и печать
def fraction(number, divisor=4):
    """
    Simplest example of function - just print
    :param number: number, which will be divide
    :param divisor: divisor
    :return: None
    """
    solid = number // divisor
    remainder = number % divisor
    print(f"{number} = {solid}*{divisor} + {remainder}")
    # А что делать, если надо иногда печатать так:
    # print(f"{number} = ({solid},{divisor},{remainder})")
    # усложнять через if?


num1 = 14
num2 = 19
div1 = 3

# Используйте debugger, чтобы лучше понять как происходит переход в
# функцию и обратно. Где видны и где не видны переменные.
print("BEGIN OF PROGRAM")
fraction(num1, div1)
fraction(num2, divisor=div1)
# Обратите внимание, что случилось в этом примере: какой делитель
fraction(num2)

print("END OF PROGRAM")
